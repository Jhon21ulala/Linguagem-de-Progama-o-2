package Proxy;


public class ServicoReal implements IServico {

    @Override
    public void realizar() {
        System.out.println("Serviço Real: operação sendo realizada...");
    }
}

