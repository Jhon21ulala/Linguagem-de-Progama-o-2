package Proxy;

public class AplicacaoProxy {

    public static void main(String[] args) {

        ServicoInterface servicoOriginal = new ServicoReal();

        testarAcesso(servicoOriginal, "usuario");
        System.out.println();
        testarAcesso(servicoOriginal, "admin");
    }

    private static void testarAcesso(ServicoInterface servico, String perfil) {
        System.out.println("Tentativa com perfil: " + perfil);
        ServicoInterface proxy = new ServicoProxy(servico, perfil);
        proxy.executar();
    }
}
