package Proxy;


public class ServicoProxy implements IServico {

    private IServico servicoReal;
    private String nivelAcesso;

    
    public ServicoProxy(IServico servico) {
        this.servicoReal = servico;
        this.nivelAcesso = "convidado";
    }

   
    public ServicoProxy(IServico servico, String perfil) {
        this.servicoReal = servico;
        this.nivelAcesso = perfil;
    }

    
    private boolean temPermissao() {
        System.out.println("Proxy: verificando acesso para o usuário '" + nivelAcesso + "'...");
        return "admin".equalsIgnoreCase(nivelAcesso);
    }

    @Override
    public void realizar() {
        if (temPermissao()) {
            System.out.println("Proxy: acesso permitido. Chamando o serviço real...");
            servicoReal.realizar();
        } else {
            System.out.println("Proxy: acesso negado. Operação não realizada.");
        }
    }
}
