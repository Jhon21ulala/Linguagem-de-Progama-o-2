package Proxy;

public class ControladorAcessoProxy implements ServicoInterface {

    private ServicoInterface servicoProtegido;

    public ControladorAcessoProxy(ServicoInterface servico) {
        this.servicoProtegido = servico;
    }

    private boolean validarAcesso() {
        System.out.println("Proxy: validando credenciais do usuário...");
        // aqui poderia existir uma lógica real de autenticação
        return true;
    }

    @Override
    public void executar() {
        System.out.println("Proxy: solicitação recebida.");

        if (validarAcesso()) {
            System.out.println("Proxy: acesso autorizado.");
            servicoProtegido.executar();
        } else {
            System.out.println("Proxy: acesso negado. Operação bloqueada.");
        }
    }
}
