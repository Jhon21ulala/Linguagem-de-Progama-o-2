package Proxy;


public interface IServico {
    
    
    void realizar();
}
