package adapter;

public class FormaQuadrada {

    private int medida;

    public FormaQuadrada(int medida) {
        this.medida = medida;
    }

    public int lado() {
        return medida;
    }
}
