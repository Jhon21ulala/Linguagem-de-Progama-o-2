package observer;

public class ObservadorDeCliente implements Receptor {

    @Override
    public void receberAtualizacao(Produto item) {
        if (item.getPromocao() == 1) {
            System.out.println("Produto com desconto! Novo valor: R$ " + item.getPreco());
        } else {
            System.out.println("Valor atual do produto: R$ " + item.getPreco());
        }
    }
}

