package observer;

public class Sistema {

    public static void main(String[] args) {

        Produto produto = new Produto("Sorvete de Coco Queimado", 10.0f);

        Cliente cliente1 = new Cliente();
        Cliente cliente2 = new Cliente();

        produto.assinar(cliente1);
        produto.assinar(cliente2);

        produto.removerAssinatura(cliente2);

        produto.executarLogicaNegocio(true);
    }
}
