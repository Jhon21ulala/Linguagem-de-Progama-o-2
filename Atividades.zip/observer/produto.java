package observer;

import java.util.ArrayList;
import java.util.Collection;

public class ItemVenda {

    private Collection<Assinantes> inscritos;
    private float valorOriginal;
    private float valorAtual;
    private boolean emOferta;
    private String nomeItem;

    public ItemVenda(String nomeItem, float valorInicial) {
        this.nomeItem = nomeItem;
        this.valorOriginal = valorInicial;
        this.valorAtual = valorInicial;
        this.emOferta = false;
        this.inscritos = new ArrayList<>();
    }

    public void registrar(Assinantes observador) {
        inscritos.add(observador);
    }

    public void cancelarRegistro(Assinantes observador) {
        inscritos.remove(observador);
    }

    private void avisarInteressados() {
        for (Assinantes obs : inscritos) {
            obs.update(this);
        }
    }

    public void atualizarPromocao(boolean ativarDesconto) {

        if (ativarDesconto) {
            valorAtual = valorOriginal * 0.5f;
            emOferta = true;
        } else {
            valorAtual = valorOriginal;
            emOferta = false;
        }

        avisarInteressados();
    }

    public float getPreco() {
        return valorAtual;
    }

    public int getPromocao() {
        return emOferta ? 1 : 0;
    }

    public String getNome() {
        return nomeItem;
    }
}
