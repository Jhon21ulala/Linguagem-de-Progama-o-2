package observer;

public interface Receptor {

    void receberAtualizacao(Produto origem);
}
