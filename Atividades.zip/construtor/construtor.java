package construtor;

import java.util.ArrayList;
import java.util.List;

public class RegistroEvento {

    private static RegistroEvento unica;

    private List<Pessoa> convidados;

    private RegistroEvento() {
        convidados = new ArrayList<>();
        adicionarPadrao();
    }

    public static RegistroEvento instanciaAtual() {
        if (unica == null) {
            unica = new RegistroEvento();
        }
        return unica;
    }

    private void adicionarPadrao() {
        convidados.add(new Pessoa("Luiz"));
        convidados.add(new Pessoa("José"));
        convidados.add(new Pessoa("Maria"));
        convidados.add(new Pessoa("João"));
    }

    public void listarConvidados() {
        System.out.println("== LISTA DE CONVIDADOS ==");
        convidados.forEach(p -> System.out.println("- " + p.getNome()));
    }
}

