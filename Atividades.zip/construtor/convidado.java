package construtor;

public class PessoaEvento {

    private String nome;

    public PessoaEvento(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
