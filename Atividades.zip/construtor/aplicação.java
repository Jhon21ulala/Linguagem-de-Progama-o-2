package construtor;

public class SistemaPrincipal {

    public static void main(String[] args) {

        ListaFesta festa = ListaFesta.getInstancia();
        festa.exibirLista();
    }
}
